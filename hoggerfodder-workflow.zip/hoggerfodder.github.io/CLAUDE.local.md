# Hogger Fodder — project context for Claude Code

This file is local and gitignored. It carries the decisions made while setting the blog up, so sessions start informed.

## What this is

A pseudonymous, slow-cadence blog. Each post takes something in World of Warcraft (Classic / WoW Forever) that seemed odd and explains the mechanism behind it with one idea from economics or maths. Written by an academic economist who tanks. Not a fan site; an economics and maths blog that uses WoW as its case study. Not anti-sim: sims give answers, reasoning explains why and when the answer changes.

- Name: **Hogger Fodder**. Tagline: **Food for thought from Azeroth**.
- Site: https://hoggerfodder.github.io (GitHub Pages, deployed by the Action on push to `main`).
- Author identity everywhere: **Hoggerfodder**. Nothing else, ever (see pseudonymity below).
- Audience: players first; theorycrafters and economists second, served by collapsible boxes.
- Pace: no schedule. Topics come from the author's curiosity, written so others can find them interesting too. Never add a posting cadence or "next week" language anywhere.
- Launch target: episode 1 live around the WoW Forever launch, 4 November 2026. Aim for three finished posts before promoting anything.

## Pseudonymity rules (hard)

- Commits must be authored as `Hoggerfodder <NNN+hoggerfodder@users.noreply.github.com>` (repo-local git config). Never change this. Never commit if `git config user.email` shows anything else.
- Never write a real name, university, city, personal email, phone or character name into any file, front matter, metadata or commit message. Dates in front matter are date-only (no time, no timezone). `timeZone = "UTC"` in hugo.toml stays.
- Strip EXIF from any image before adding it. No screenshots that show a character name.
- No `--force` pushes; history is public.

## Stack and conventions

- Hugo (extended, pinned in `.github/workflows/hugo.yml`), hand-written layouts in `layouts/`, one stylesheet `assets/css/site.css`. No theme, no framework, no JS beyond KaTeX (per page, `math: true`) and giscus. Keep pages light and phone-friendly; no horizontal scroll at 390px.
- Workflow script `./blog`: `blog new "Title"` (folder from archetype + NOTES.md, opens editor, starts preview), `blog open`, `blog preview`, `blog save` (commit + push drafts, no checks; end of every writing session), `blog check` (would it publish cleanly: identity, title, description, placeholders, build), `blog publish` (gate → strip image EXIF → draft:false, lastmod → commit "Post: Title" → push), `blog list`. Editor via `BLOG_EDITOR` (default omawrite; Obsidian or nvim work the same, posts are plain .md).
- Posts: `content/posts/YYYY-MM-DD-slug/index.md`, created with `blog new`. Figures, data and interactives live in the same folder. `.html` files there are published as-is beside the post (hugo.toml restricts content types to Markdown) and embedded with `<iframe src="name.html" …>`.
- Post shape (archetype `archetypes/posts.md`): opening puzzle → `> **The short version.**` box → mechanism for a sharp guildmate → `<details><summary>The maths</summary>` → `> **Numbers as of patch X.Y.**` box (every patch-dependent constant, marked confirmed or inferred) → `<details><summary>For economists</summary>` → `## Revisions` list. Propositions as `> **Proposition 1.**` blockquotes. Blank line after `<summary>` and before `</details>`.
- Each post folder may hold a `NOTES.md` (gitignored): the author's raw thoughts. "Draft the post from NOTES.md" means: follow the archetype shape, keep every idea and number from the notes, invent nothing, mark any constant you are unsure of as *inferred*, and leave the Numbers box for the author to verify.
- `draft: true` until the author is happy with it. Their own checklist, not enforced by anything: opens with the odd thing; result and intuition within two screens; every number checked by the author; one figure or interactive that does the explaining; maths and the economists' aside collapsed, not removed; `description` written (it is the link preview); `lastmod` set.
- Corrections from readers go into Revisions with credit. Bump `lastmod`.
- `content/mechanisms.md` is the index of mechanisms; add a row for every published post.
- Comments: giscus on GitHub Discussions; `repoId` and `categoryId` in hugo.toml still need filling from https://giscus.app.
- Tips: Ko-fi link in the footer and a one-line tip-line at the end of each post (template, not Markdown). No widgets.
- Licence: text and figures CC BY-NC 4.0, code MIT. Footer carries the non-affiliation line.
- Writing: drafting may be AI-assisted and the about page says so. Voice is a person talking to a guildmate, not a paper. No "In this post we will". Australian/British spelling. Avoid the words "genuinely", "honestly", "straightforward".
- Preview: `blog preview` (or `hugo server -D`). Publish: `blog publish` (normal commits only; never --force).
- Commit messages: "Post: Title" for posts, short imperative otherwise. Always check `git config user.email` matches the noreply address before committing; the gate enforces it on publish.

## Episode candidates (from earlier discussion)

1. **The uncrushable cap** (episode 1, worked out already): why 102.4%, caps as kinks, the attack table as a capital structure, priority absorption vs pro rata vs independent rolls as claims rules. Interactive: the "ruler" — sliders for miss/dodge/parry/block, a stacked attack-table bar, crush then crit truncated as the sum rises, a marker at the threshold, marginal value of each stat; constants in one object at the top; state in the URL hash; presets; boss level 63 vs 60 toggle; dark mode via prefers-color-scheme; self-contained HTML, no libraries.
2. **Proportional renormalisation is path-dependent**: why "boosted stat keeps face value, others shrink pro rata" cannot be a function of gear; what Blizzard chose instead and why.
3. **Shadow prices**: marginal value of a stat at and past a cap; complementary slackness.
4. **Option value of flexible gear.**
5. **Boosting, a critical take**: a market for carries with real gains from trade, versus externalities (empty levelling world, gold demand feeding bots/RMT, erosion of group content); nerfs as externality pricing, judged on whether the price was right.
6. **Addons that play for you** (Fojji rotation WeakAuras, Hekili, Blizzard's Rotation Assist with its 0.2 s one-button penalty): what the rotation measured once automated, what parses still signal, whether the penalty is a sensible tax on automation.
7. **Rage vs mana**: mana as a stock against a time budget (easy to tune); rage as positive feedback (gear → rage → damage), hence warrior gear scaling and repeated re-tuning (rage normalisation); refund talents (Illumination, Clearcasting, Master of Elements, Judgement of Wisdom) as partial feedback; how much feedback a resource can carry before it stops being tunable.
8. Later: the Lucas critique, once readers have seen the method work.

## Promotion (per post, then stop)

Post the link where the confusion lives (Forever beta forums, r/classicwow, r/wow where relevant) with a short intro; reply to comments for 48 hours; fold corrections in with credit; then stop. Ask readers for logged data where coefficients are unconfirmed. No schedule promises, no engagement bait, no replying to hostility.

## Pages to add later

- `content/coffee.md`, "the coffee ledger": one line per coffee bought with tips (date, beans or brew, which post paid). Linked from the about page and the tip line, not the nav. No cafe names or locations. Doubles as the tips log for tax.

## Still to do

- giscus ids into hugo.toml.
- Delete `content/posts/2026-10-14-sample-post/` once episode 1 exists.
- Layout pass once the author has looked at the live site (type, accent colour, a mark of our own design — never Blizzard art).
- Tips log (date, amount, platform) for tax; tips are assessable income.
