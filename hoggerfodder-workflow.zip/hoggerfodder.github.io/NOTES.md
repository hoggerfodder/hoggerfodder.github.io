# Working notes (gitignored, local only)

## Writing a post

```bash
./blog new "The uncrushable cap"   # folder from the archetype, NOTES.md beside it, editor + preview open
./blog save                        # end of a session: commit + push drafts, no checks
./blog check                       # would it publish cleanly: identity, description, placeholders, build
./blog publish                     # gate, strip EXIF, draft:false, lastmod, commit, push
./blog list                        # what's draft and what's live
```

`blog open` and `blog preview` take an optional slug; without one they pick the latest draft. Set `BLOG_EDITOR=obsidian` (or nvim) to change the editor.

Write in Omawrite; see the real render at http://localhost:1313 (reloads on save). For AI drafting: dump thoughts in the post's NOTES.md, then in Claude Code say "draft the post from NOTES.md".

## One-time

- Comments: https://giscus.app → this repo, category General → paste `repoId` and `categoryId` into `hugo.toml`.
- Delete `content/posts/2026-10-14-sample-post/` once episode 1 exists (it's a draft, so it never publishes, but it's in the public source).
- Repo git identity: `git config user.email` must be the `+hoggerfodder@users.noreply.github.com` address.

## Layout

```
hugo.toml              site config, giscus ids, maths passthrough
layouts/               templates (no theme)
assets/css/site.css    the one stylesheet; light/dark follow the system
archetypes/posts.md    post template
content/posts/         one folder per post
content/about.md       the promise, the policy, the name
content/mechanisms.md  index of mechanisms, grown with every post
.github/workflows/     build and deploy, Hugo version pinned
```
